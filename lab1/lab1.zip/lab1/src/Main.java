import Controller.Requests;

public class Main {
    public static void main(String args[]) {
        Requests req = new Requests();
        req.Start();
    }
}